# MOG #

On [WordPress.org][l1], or preview at [wp-themes.com][l2] (May be outdated).

A simple, clean and minimalist 1 column WordPress theme.
Build on top of _s and inspired  by [Manifest](http://themes.jimbarraud.com/manifest/).

![Screenshot](screenshot.png)

This is my first WordPress theme. Still struggling around with the structure of the WordPress, it is still mostly based on _s and most changes are in the CSS files.

[l1]: http://wordpress.org/themes/mog
[l2]: http://wp-themes.com/mog/