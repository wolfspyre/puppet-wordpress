// JavaScript Document
jQuery(window).ready(function() {var date = jQuery('.ast_date').datepicker({ dateFormat: 'dd MM yy' }).val();});