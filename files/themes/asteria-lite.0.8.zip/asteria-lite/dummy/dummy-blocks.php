<!--Blocks-->
<div class="home_blocks">
<div class="midrow">

 <div class="midrow_wrap">       
        <div class="midrow_blocks">   
        <div class="midrow_blocks_wrap">
        
        <div class="midrow_block">
            <div class="mid_block_content">
            <div class="block_img"><div class="icon_wrap"><i class="fa-camera fa-2x"></i></div></div>
            <h3>We Work Efficiently</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam nec rhoncus risus. In ultrices lacinia ipsum, posuere faucibus velit bibendum ac.</p>
            </div>
        </div>

        
        <div class="midrow_block">
            <div class="mid_block_content">
            <div class="block_img"><div class="icon_wrap"><i class="fa-rocket fa-2x"></i></div></div>
            <h3>24/7 Live Support</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam nec rhoncus risus. In ultrices lacinia ipsum, posuere faucibus velit bibendum ac. Sed ultrices leo.</p>
            </div>
        </div>
        
        
        <div class="midrow_block">
            <div class="mid_block_content">
            <div class="block_img"><div class="icon_wrap"><i class="fa-signal fa-2x"></i></div></div>
            <h3>Confide</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam nec rhoncus risus. In ultrices lacinia ipsum, posuere faucibus velit bibendum ac.</p>
            </div>
        </div>
        
        
        <div class="midrow_block">
            <div class="mid_block_content">
            <div class="block_img"><div class="icon_wrap"><i class="fa-cogs fa-2x"></i></div></div>
            <h3>Gurantee Like No Other</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam nec rhoncus risus. In ultrices lacinia ipsum, posuere faucibus velit bibendum ac.</p>
            </div>
        </div>
</div>
        </div>
                        
    </div>

</div>
</div>
<!--Blocks END-->
<div class="home_blocks">
    <div class="text_block">
        <div class="text_block_wrap"><div class="center"><h2>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam nec rhoncus risus. In ultrices lacinia ipsum, posuere faucibus velit bibendum ac.</h2></div></div>
    </div>
</div>