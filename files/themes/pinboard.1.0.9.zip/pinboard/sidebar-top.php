<?php if( is_active_sidebar( 2 ) ) : ?>
	<div id="sidebar-top" class="widget-area" role="complementary">
		<?php dynamic_sidebar( 2 ) ; ?>
	</div><!-- #sidebar-top -->
<?php endif; ?>