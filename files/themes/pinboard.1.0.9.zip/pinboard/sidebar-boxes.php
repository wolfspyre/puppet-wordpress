<?php if( is_active_sidebar( 9 ) ) : ?>
	<div id="sidebar-boxes" class="widget-area" role="complementary">
		<?php dynamic_sidebar( 9 ) ; ?>
	</div><!-- #sidebar-home -->
<?php endif; ?>