<?php if( is_active_sidebar( 8 ) ) : ?>
	<div id="sidebar-wide" class="widget-area" role="complementary">
		<?php dynamic_sidebar( 8 ) ; ?>
		<div class="clear"></div>
	</div><!-- #sidebar-home -->
<?php endif; ?>