
jQuery(document).ready(function($){
	$( '#loginform' ).append( $( '#wpcc-sign-on' ) );
});
