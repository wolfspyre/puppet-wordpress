<?php
/**
 * Module Name: Contact Form
 * Module Description: Easily insert a contact form anywhere on your site.
 * Sort Order: 9
 * First Introduced: 1.3
 * Requires Connection: No
 * Auto Activate: Yes
 * Module Tags: Other
 */

include dirname( __FILE__ ) . '/contact-form/grunion-contact-form.php';
